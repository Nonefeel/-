Version:	AC700N_earphone_release_V1.2.0
CommitID: 			
CommitDate: 		
Date: 2021/11/19			
Author: QHH			
Log:				-
1、功能增加: 话务耳机做回音消除
2、使用方法：
    可以直接替换的文件：aec.a、libDualMicSystem_flexible_pi32v2_OnChip.a、bluetooth_v1.lua
    要对比修改的文件：audio_aec_dms.c、commproc_dms.h

	