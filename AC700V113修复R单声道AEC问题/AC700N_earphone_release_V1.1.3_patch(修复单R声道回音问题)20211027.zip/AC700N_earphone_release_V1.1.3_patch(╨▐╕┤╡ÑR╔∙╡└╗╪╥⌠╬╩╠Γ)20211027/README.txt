Version:AC700N_V1.1.3		--补丁适用版本
CommitID:4c2f608		--方便日后查阅和修改（前面7个数字，cherry pick刚好用前面7个id）
CommitDate:2021/10/27		--方便日后查阅和修改
Date:2021/10/27			--补丁发布日期
Author:HJH			--写自己的名字首字母
Log:				--写到别人一看就知道是什么，怎么改
1、fix: 修复DAC选择单声道R的时候，CVP参考数据是双声道，需要按照双声道处理